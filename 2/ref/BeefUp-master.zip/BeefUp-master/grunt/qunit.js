// https://github.com/gruntjs/grunt-contrib-qunit

module.exports = {
    all: {
        src: ['test/**/*.html']
    }
};
